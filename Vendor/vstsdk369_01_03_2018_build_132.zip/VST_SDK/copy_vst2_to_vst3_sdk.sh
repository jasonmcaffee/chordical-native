#!/bin/sh

cp -r VST2_SDK/* VST3_SDK

