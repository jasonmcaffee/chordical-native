var futils_8h =
[
    [ "Min", "futils_8h.html#affba9ed0dfe13309d79094f10bbc6021", null ],
    [ "Max", "futils_8h.html#a0f480f7384f085c2606eff5f310ad194", null ],
    [ "Abs", "futils_8h.html#aba3ecff4e181af61d1fb90a1ebdddf4b", null ],
    [ "Sign", "futils_8h.html#aa79ff23f611f74e51508de6f934d9b74", null ],
    [ "Bound", "futils_8h.html#a1d0f063a19e621ae10e8e532e0ce3395", null ],
    [ "Swap", "futils_8h.html#afc06120bebe47474d1e6c5bfa4eb66b8", null ],
    [ "IsApproximateEqual", "futils_8h.html#af300911d7995de5985af548ee4eadcf4", null ],
    [ "ToNormalized", "futils_8h.html#a3b853af91258cfec3aaaf03bff12541b", null ],
    [ "FromNormalized", "futils_8h.html#a15c8c1bdcb98836c8074a36c9458c048", null ]
];