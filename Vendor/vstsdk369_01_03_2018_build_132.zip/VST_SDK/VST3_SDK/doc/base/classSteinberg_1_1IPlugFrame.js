var classSteinberg_1_1IPlugFrame =
[
    [ "resizeView", "classSteinberg_1_1IPlugFrame.html#a94f218315acd695606fff41166294d56", null ]
];