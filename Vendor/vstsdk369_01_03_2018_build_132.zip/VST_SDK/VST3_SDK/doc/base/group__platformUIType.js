var group__platformUIType =
[
    [ "kPlatformTypeHWND", "group__platformUIType.html#gaa1e68ac1f25da9c85c937d0360dbc601", null ],
    [ "kPlatformTypeHIView", "group__platformUIType.html#ga974cabea219cb31ad8218ba15d1f7071", null ],
    [ "kPlatformTypeNSView", "group__platformUIType.html#ga8ce69944b5475d65206469b9ebcbf755", null ],
    [ "kPlatformTypeUIView", "group__platformUIType.html#ga6362a7ca65b87d30c561dac986b757bd", null ],
    [ "kPlatformTypeX11EmbedWindowID", "group__platformUIType.html#gac945decc5f26f3fdb5419e8de833a0e1", null ]
];