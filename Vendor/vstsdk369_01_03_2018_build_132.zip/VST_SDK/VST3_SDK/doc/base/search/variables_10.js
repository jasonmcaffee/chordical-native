var searchData=
[
  ['vendor',['vendor',['../structSteinberg_1_1PFactoryInfo.html#ac4707b8abe69c6961d88a0ea8d9689e0',1,'Steinberg::PFactoryInfo::vendor()'],['../structSteinberg_1_1PClassInfo2.html#a7540fc2f4cee3145736c7e3083367aba',1,'Steinberg::PClassInfo2::vendor()'],['../structSteinberg_1_1PClassInfoW.html#abb5e59029c2e7b356dd264eae82de3a4',1,'Steinberg::PClassInfoW::vendor()']]],
  ['version',['version',['../structSteinberg_1_1PClassInfo2.html#a10a16351d8da082eba2e5cbd16e6aed1',1,'Steinberg::PClassInfo2::version()'],['../structSteinberg_1_1PClassInfoW.html#a5361068d8071d34e2142025ab72bcc6b',1,'Steinberg::PClassInfoW::version()']]],
  ['virt',['virt',['../structSteinberg_1_1KeyCode.html#a710c5cefa06d25fe01febb579ab09a7d',1,'Steinberg::KeyCode']]]
];
