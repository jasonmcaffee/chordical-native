var searchData=
[
  ['query_5finterface',['QUERY_INTERFACE',['../funknown_8h.html#a1884893f6b75952d6e29bcd333f3ea40',1,'funknown.h']]]
];
