var searchData=
[
  ['platform_20ui_20types',['Platform UI Types',['../group__platformUIType.html',1,'']]]
];
